//
//  TaggedProgressView.swift
//  SpatialDJ
//
//  Created by Kosta Sechkar on 29.05.2023.
//

import UIKit

class TaggedProgressView: UIProgressView {
    var tag: Int = 1

}
